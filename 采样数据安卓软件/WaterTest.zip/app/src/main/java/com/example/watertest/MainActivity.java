package com.example.watertest;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;



public class MainActivity extends AppCompatActivity {

    // MQTT服务器地址和端口
    private static final String BROKER = "tcp://111.229.123.25:1883";
    // 客户端ID（可以自定义）
    private static final String CLIENT_ID = "12";
    // 要订阅的主题
    private static final String TOPIC = "data1";
    // MQTT服务器的用户名
    private static final String USERNAME = "user1";
    // MQTT服务器的密码
    private static final String PASSWORD = "123456";

    private MqttClient client;
    // 连接标志  0:未连接  1:已连接
    int sign=0;
    String payload,mark;
    Button btn1;
    TextView text1,PH,temp,turbidity;
    LineChart lineChart;
    ArrayList<Entry> entries;
    LineDataSet dataSet;
    LineData lineData;
    String TAG="mmm";
    float value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        entries=new ArrayList<>();

        setContentView(R.layout.activity_main);
        btn1=findViewById(R.id.button1);
        PH=findViewById(R.id.ph);
        temp=findViewById(R.id.temp);
        turbidity=findViewById(R.id.turbidity);
        text1=findViewById(R.id.text1);
        lineChart=findViewById(R.id.lineChart);
        setLineChart();

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // 如何未连接状态
                if (sign==0){
                    // 创建一个新线程，避免在主线程中进行网络操作
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            connectAndSubscribe();
                            try {
                                MqttMessage message = new MqttMessage();
                                String payload = "Hello";
                                message.setPayload(payload.getBytes());
                                Log.d(TAG, "成功");


                                text1.setText("状态:已连接");
                                btn1.setText("断开连接");
                                sign=1;
                                text1.setBackgroundResource(R.drawable.text12);


                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }).start();
                }

                // 如果处于连接状态
                if (sign==1){
                    try {
                        client.disconnect();
                        btn1.setText("连接服务器");
                        text1.setText("状态:未连接");
                        text1.setBackgroundResource(R.drawable.text11);
                        sign=0;
                        Toast.makeText(MainActivity.this, "断开连接", Toast.LENGTH_SHORT).show();
                    } catch (MqttException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        // 暂时假设一些数值
        float yValues=0;
        addValue(yValues);
    }

    private void setLineChart(){
        // 创建一条线
        dataSet=new LineDataSet(null,"浑浊度");
        //线模式为圆滑曲线（默认折线）
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        //设置曲线值的圆点是实心还是空心
        dataSet.setDrawCircleHole(false);
        // 线的颜色
        dataSet.setColor(Color.parseColor("#98F5FF"));
        // 节点的颜色
        dataSet.setCircleColor(Color.parseColor("#8EE5EE"));
        // 节点的圆点的大小
        dataSet.setCircleRadius(6f);
        // 设置线的宽度
        dataSet.setLineWidth(3.3f);
        // 节点值的颜色
        dataSet.setValueTextColor(Color.parseColor("#00F5FF"));
        dataSet.setDrawValues(false);
        // 节点值的大小
        dataSet.setValueTextSize(17f);

        // 获取折线图的右侧Y轴
        YAxis rightAxis=lineChart.getAxisRight();
        // 设置Y轴右侧标识不可见
        rightAxis.setEnabled(false);
        // 实例化X轴的值
        XAxis xAxis=lineChart.getXAxis();
        // 将X轴的值的颜色
        xAxis.setTextColor(Color.parseColor("#00F5FF"));
        // 设置X轴的值大小
        xAxis.setTextSize(18f);
        // 设置X轴的轴线可见
        xAxis.setDrawAxisLine(true);
        // 设置X轴的网格线可见
        xAxis.setDrawGridLines(true);
        // 设置X轴的标签可见
        xAxis.setDrawLabels(true);
        // 设置X轴标签的位置为底部
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        // 设置X轴值的格式化器
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
//                return String.valueOf((int)value+1).concat("月");
                return String.valueOf((int)value+1);
            }
        });
        // 获取折线图的图例
        Legend legend=lineChart.getLegend();
        // 设置图例形状为线
        legend.setForm(Legend. LegendForm. LINE);
        // 设置图例的文字大小
        legend.setTextSize(15f);
        // 设置图例形状的大小
        legend.setFormSize(15f);
        // 设置图例的文字颜色
        legend. setTextColor(Color. BLUE);
        // 获取折线图的描述
        Description description=lineChart.getDescription();
        // 设置描述不可见
        description.setEnabled(false);
        // 设置折线图的数据为LineData对象
        lineData=new LineData(dataSet);
        // 设置折线图的触摸事件不可用
        lineChart.setTouchEnabled(true);
        // 设置折线图的数据
        lineChart.setData(lineData);
        // 刷新折线图
        lineChart.invalidate();
    }

    /**
     * 动态添加数据
     * 在一个LineChart中存放的折线，其实是以索引从0开始编号的
     *
     * @param yValues y值
     */
    public void addEntry(LineData lineData, LineChart lineChart, float yValues, int index) {

        // 通过索引得到一条折线，之后得到折线上当前点的数量
        float xCount = lineData.getDataSetByIndex(index).getEntryCount();


        Entry entry = new Entry(xCount, yValues); // 创建一个点
        lineData.addEntry(entry, index); // 将entry添加到指定索引处的折线中

        //通知数据已经改变
        lineData.notifyDataChanged();
        lineChart.notifyDataSetChanged();

        //把yValues移到指定索引的位置
        lineChart.moveViewToAnimated(xCount - 4, yValues, YAxis.AxisDependency.LEFT, 1000);// TODO: 2019/5/4 内存泄漏，异步 待修复
        lineChart.invalidate();
    }
    private void addValue(float yValues){
        addEntry(lineData, lineChart, yValues,0);
        lineChart.invalidate();
    }



    private void connectAndSubscribe() {
        try {
            // 创建一个新的MQTT客户端对象
            client = new MqttClient(BROKER, CLIENT_ID, new MemoryPersistence());
            // 设置连接选项，包括用户名和密码
            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName(USERNAME);
            options.setPassword(PASSWORD.toCharArray());
            // 连接到MQTT服务器
            client.connect(options);
            // 订阅指定主题
            client.subscribe(TOPIC);
            // 设置消息回调
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable throwable) {
                    // 连接丢失时的处理逻辑
                    Log.d("MQTT", "连接丢失");
                    sign=0;
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    // 接收到消息时的处理逻辑
                    payload = new String(message.getPayload());
                    Log.d("MQTT", "接收到消息：" + payload);
                    // 在UI线程更新UI
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            text1.setText("状态:已连接");
                            btn1.setText("断开连接");
                            sign=1;
                            text1.setBackgroundResource(R.drawable.text12);
                            mark=payload.substring(0,1);
                            Log.d("MQTT", mark);
                            if (mark.equals("0")){
                                PH.setText(payload.substring(2));
                                Log.d("MQTT",payload.substring(2));
//                                PH.postInvalidate();
                            }
                            if (mark.equals("1")){
                                temp.setText(payload.substring(2)+"℃");
                            }
                            if (mark.equals("2")){
                                value= Float.parseFloat(payload.substring(2));
                                addValue(value);
                                turbidity.setText(payload.substring(2)+" NTU");
                            }
                        }
                    });
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    // 消息发送完成时的处理逻辑
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 断开与MQTT服务器的连接
        if (client != null && client.isConnected()) {
            try {
                client.disconnect();
                sign=0;
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
    }
}