#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/adc.h"
#include "driver/uart.h"
#include "esp_log.h"
#include <stdio.h>
#include <string.h>

// 定义串口相关的参数
#define UART_NUM_SEND UART_NUM_1 // 发送数据的串口号
#define BUF_SIZE (1024)          // 缓冲区大小

// 定义ADC相关的参数
#define ADC_CHANNEL_1 ADC1_CHANNEL_4 // ADC通道1，连接到GPIO32
#define ADC_CHANNEL_2 ADC1_CHANNEL_5 // ADC通道2，连接到GPIO33
#define ADC_CHANNEL_3 ADC1_CHANNEL_6 // ADC通道3，连接到GPIO34

// 定义发送数据任务的栈大小和优先级
#define TX_TASK_STACK_SIZE (2048)
#define TX_TASK_PRIORITY (10)

// 串口配置结构体
const uart_config_t uart_config = {
    .baud_rate = 115200, // 波特率
    .data_bits = UART_DATA_8_BITS,
    .parity = UART_PARITY_DISABLE,
    .stop_bits = UART_STOP_BITS_1,
    .flow_ctrl = UART_HW_FLOWCTRL_DISABLE};

// 初始化ADC
static void adc_init()
{
    adc1_config_width(ADC_WIDTH_BIT_12);                       // 设置ADC的位宽为12位
    adc1_config_channel_atten(ADC_CHANNEL_1, ADC_ATTEN_DB_11); // 设置ADC通道1的衰减为11dB
    adc1_config_channel_atten(ADC_CHANNEL_2, ADC_ATTEN_DB_11); // 设置ADC通道2的衰减为11dB
    adc1_config_channel_atten(ADC_CHANNEL_3, ADC_ATTEN_DB_11); // 设置ADC通道3的衰减为11dB
}

// 发送数据任务的函数
void uart_send_task(void *pvParameters)
{
    while (1)
    {
        int adc_val1 = adc1_get_raw(ADC_CHANNEL_1); // 读取ADC通道1的原始值
        int adc_val2 = adc1_get_raw(ADC_CHANNEL_2); // 读取ADC通道2的原始值
        int adc_val3 = adc1_get_raw(ADC_CHANNEL_3); // 读取ADC通道3的原始值

        // 数据一起发
        char data[60];
        sprintf(data, "0=%d|1=%d|2=%d|\r\n", adc_val1, adc_val2, adc_val3);
        int len = strlen(data);
        uart_write_bytes(UART_NUM_SEND, data, len);


        // 数据分开发
        // 将ADC值打包成字符串
        // char data0[30];
        // char data1[30];
        // char data2[30];
        
        // sprintf(data0, "0=%d\r\n", adc_val1);
        // sprintf(data1, "1=%d\r\n", adc_val2);
        // sprintf(data2, "2=%d\r\n", adc_val3);

        // int len0 = strlen(data0);
        // int len1 = strlen(data1);
        // int len2 = strlen(data2);
        // // 发送数据到串口
        // uart_write_bytes(UART_NUM_SEND, data0, len0);
        // vTaskDelay(pdMS_TO_TICKS(50));
        // uart_write_bytes(UART_NUM_SEND, data1, len1);
        // vTaskDelay(pdMS_TO_TICKS(50));
        // uart_write_bytes(UART_NUM_SEND, data2, len2);

        vTaskDelay(pdMS_TO_TICKS(1000)); // 每隔1秒发送一组数据
    }
}

void app_main()
{
    // 配置串口参数
    uart_param_config(UART_NUM_SEND, &uart_config);

    // 设置串口引脚（TX: IO18）
    uart_set_pin(UART_NUM_SEND, 18, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);

    // 安装驱动程序
    uart_driver_install(UART_NUM_SEND, BUF_SIZE * 2, 0, 0, NULL, 0);

    // 初始化ADC
    adc_init();

    // 创建发送数据任务
    xTaskCreate(uart_send_task, "uart_send_task", TX_TASK_STACK_SIZE, NULL, TX_TASK_PRIORITY, NULL);
}
